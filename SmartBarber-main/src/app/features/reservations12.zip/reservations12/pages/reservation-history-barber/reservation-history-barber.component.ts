import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { SessionService } from '../../../../core/auth/services/session.service';
import { FirebaseAuthService } from '../../../../core/auth/services/firebase-auth.service';
import { environment } from '../../../../../environments/environment';
import { catchError, forkJoin, of } from 'rxjs';

export interface UnifiedReservationItem {
  id: string;
  source: 'EMPLOYEE' | 'BARBER';
  notes?: string;
  status: string;
  startTime: string;
  duration?: number;
  creationDate?: string;
}

@Component({
  selector: 'app-client-barber-history',
  standalone: true,
  imports: [CommonModule, HttpClientModule],
  templateUrl: './client-barber-history.component.html',
  styleUrls: ['./client-barber-history.component.css']
})
export class ClientBarberHistoryComponent implements OnInit {
  private readonly http = inject(HttpClient);
  private readonly sessionService = inject(SessionService);
  private readonly firebaseAuthService = inject(FirebaseAuthService);

  historyList: UnifiedReservationItem[] = [];
  isLoading = true;
  errorMessage = '';

  ngOnInit(): void {
    this.loadCombinedHistory();
  }

  async loadCombinedHistory(): Promise<void> {
    const session = this.sessionService.currentSession;
    // Tomamos dinámicamente el employeeId (o userId) y permitimos usar el ID fijo del barbero proporcionado o de la sesión
    const employeeId = session?.userId; 
    const barberId = '55c1c44d-49ab-4267-b6f5-f6e78028b9f6'; // ID fijo solicitado

    this.isLoading = true;
    this.errorMessage = '';

    try {
      const token = await this.firebaseAuthService.getIdToken();
      const headers = new HttpHeaders({
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
      });

      const baseUrl = environment.apiUrl || 'http://localhost:8080';

      // Definimos los endpoints solicitados
      const employeeEndpoint = employeeId 
        ? `${baseUrl}/reservation-service/employee/${employeeId}` 
        : null;
      
      const barberEndpoint = `${baseUrl}/reservation-service/barber/${barberId}`;

      // Peticiones observables seguras con manejo de errores independientes para no romper todo si uno falla
      const employeeReq$ = employeeEndpoint 
        ? this.http.get<any[]>(employeeEndpoint, { headers }).pipe(catchError(() => of([])))
        : of([]);

      const barberReq$ = this.http.get<any[]>(barberEndpoint, { headers }).pipe(catchError(() => of([])));

      forkJoin({
        employeeData: employeeReq$,
        barberData: barberReq$
      }).subscribe({
        next: (res) => {
          const mapResults = new Map<string, UnifiedReservationItem>();

          // Procesar datos de Empleado
          if (Array.isArray(res.employeeData)) {
            res.employeeData.forEach((item: any) => {
              mapResults.set(item.id, {
                id: item.id,
                source: 'EMPLOYEE',
                notes: item.notes || item.serviceName || 'Servicio de Empleado',
                status: item.status || 'PENDING',
                startTime: item.startTime || item.date || new Date().toISOString(),
                duration: item.duration || 0,
                creationDate: item.creationDate || item.createdAt || new Date().toISOString()
              });
            });
          }

          // Procesar datos de Barbero
          if (Array.isArray(res.barberData)) {
            res.barberData.forEach((item: any) => {
              mapResults.set(item.id, {
                id: item.id,
                source: 'BARBER',
                notes: item.notes || item.serviceName || 'Corte / Servicio Barbero',
                status: item.status || 'PENDING',
                startTime: item.startTime || item.date || new Date().toISOString(),
                duration: item.duration || 0,
                creationDate: item.creationDate || item.createdAt || new Date().toISOString()
              });
            });
          }

          this.historyList = Array.from(mapResults.values());
          this.isLoading = false;
        },
        error: (err) => {
          console.error('Error al sincronizar historiales:', err);
          this.errorMessage = 'No se pudo conectar con los servicios de reservas.';
          this.isLoading = false;
        }
      });

    } catch (err: any) {
      console.error('Error de autenticación:', err);
      this.errorMessage = 'Error al obtener credenciales de sesión.';
      this.isLoading = false;
    }
  }

  get activeReservesCount(): number {
    return this.historyList.filter(item => ['CONFIRMED', 'COMPLETED', 'APPROVED', 'ACTIVE'].includes(item.status)).length;
  }

  get totalMinutes(): number {
    return this.historyList.reduce((acc, item) => acc + (Number(item.duration) || 0), 0);
  }
}